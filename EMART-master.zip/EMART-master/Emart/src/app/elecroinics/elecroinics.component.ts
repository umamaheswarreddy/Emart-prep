import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elecroinics',
  templateUrl: './elecroinics.component.html',
  styleUrls: ['./elecroinics.component.css']
})
export class ElecroinicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
